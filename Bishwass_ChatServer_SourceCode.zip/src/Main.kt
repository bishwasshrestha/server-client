
//BISHWAS SHRESTHA (ID- 1706204)
/*This is the main function that calls serversocket and allocates clients its server space*/

fun main(args: Array<String>){

    ChatServer().serve()
}