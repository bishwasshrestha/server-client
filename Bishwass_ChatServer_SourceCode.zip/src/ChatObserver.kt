
//BISHWAS SHRESTHA (ID- 1706204)
//This is an observer Interface that updates the observers terminal once the update function is called.
interface ChatObserver {

    fun update(text:String)
}
